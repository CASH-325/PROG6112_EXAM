package question2;

import javax.swing.*;
import java.awt.GridLayout;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class ProductApp extends JFrame {

    private final JTextField txtName = new JTextField();
    private final JTextField txtPrice = new JTextField();
    private final JComboBox<String> cmbProduct = new JComboBox<>(new String[]{
            "Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"});

    public ProductApp() {
        setTitle("Product App");
        setSize(450, 250);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // ----- Menu system (Q.2.4) -----
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem exitItem = new JMenuItem("Exit");
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem clearItem = new JMenuItem("Clear");
        fileMenu.add(exitItem);
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);
        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);

        // ----- Form objects (Q.2.2) -----
        JButton btnProcess = new JButton("PROCESS");
        setLayout(new GridLayout(4, 2, 10, 10));
        add(new JLabel("  Customer Name:"));
        add(txtName);
        add(new JLabel("  Select Product:"));
        add(cmbProduct);
        add(new JLabel("  Enter Price:"));
        add(txtPrice);
        add(new JLabel());
        add(btnProcess);

        // ----- Event handlers: the menu item and button share one method -----
        btnProcess.addActionListener(e -> processSale());
        processItem.addActionListener(e -> processSale());
        clearItem.addActionListener(e -> clearForm());
        exitItem.addActionListener(e -> System.exit(0));
    }

    // Q.2.3: calculate, display and save
    private void processSale() {
        String name = txtName.getText().trim();
        String product = (String) cmbProduct.getSelectedItem();

        double price;
        try {
            price = Double.parseDouble(txtPrice.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid numeric price.",
                    "Invalid input", JOptionPane.ERROR_MESSAGE);
            return;
        }

        IProductCalculations calc = new ProductCalculations(price);
        double vat = calc.GetVat();
        double commission = calc.GetCommission();
        double total = calc.GetTotal();

        String details = "Customer Name: " + name + "\n"
                + "Product: " + product + "\n"
                + "VAT: R " + vat + "\n"
                + "COMMISSION: R " + commission + "\n"
                + "TOTAL: R " + total;

        JOptionPane.showMessageDialog(this, details, "Message", JOptionPane.INFORMATION_MESSAGE);
        saveToFile(details);
    }

    // Writes the data log to data.txt
    private void saveToFile(String details) {
        try (PrintWriter writer = new PrintWriter(new FileWriter("data.txt"))) {
            writer.println("DATA LOG");
            writer.println("*****************************************");
            writer.println(details);
            writer.println("*****************************************");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Could not save file: " + ex.getMessage());
        }
    }

    // Clear text boxes and reset combo box to index 0
    private void clearForm() {
        txtName.setText("");
        txtPrice.setText("");
        cmbProduct.setSelectedIndex(0);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ProductApp().setVisible(true));
    }
}
