package question1;

/** Calculates sales statistics from a 2D array (rows = products, columns = months). */
public class Product implements IProducts {

    private final String[] productNames;   // 1D array of product names
    private final int[][] sales;           // 2D array of monthly sales

    public Product(String[] productNames, int[][] sales) {
        this.productNames = productNames;
        this.sales = sales;
    }

    // Adds up every value in the 2D array
    @Override
    public int GetTotalProductsSold() {
        int total = 0;
        for (int[] productSales : sales) {
            for (int monthSales : productSales) {
                total += monthSales;
            }
        }
        return total;
    }

    // Total divided by the number of entries (3 products x 3 months = 9)
    @Override
    public double GetAverageProductSold() {
        int entries = sales.length * sales[0].length;
        return (double) GetTotalProductsSold() / entries;
    }

    // Finds the product with the highest total sales
    @Override
    public String GetMostPopularProduct() {
        int bestIndex = 0;
        int bestTotal = 0;
        for (int i = 0; i < sales.length; i++) {
            int productTotal = 0;
            for (int monthSales : sales[i]) {
                productTotal += monthSales;
            }
            if (productTotal > bestTotal) {
                bestTotal = productTotal;
                bestIndex = i;
            }
        }
        return productNames[bestIndex] + " (" + bestTotal + ")";
    }
}
