package question1;

import java.text.DecimalFormat;

/** Responsible only for printing the report data. */
public class PrintProduct {

    private final IProducts product;

    public PrintProduct(IProducts product) {
        this.product = product;
    }

    public void printTotalProductSales() {
        System.out.println("TOTAL PRODUCT SALES: " + product.GetTotalProductsSold());
    }

    public void printAverageProductSales() {
        DecimalFormat df = new DecimalFormat("0.##");   // 17.0 prints as 17
        System.out.println("AVERAGE PRODUCT SALES: " + df.format(product.GetAverageProductSold()));
    }

    public void printMostPopularProduct() {
        System.out.println("MOST POPULAR PRODUCT: " + product.GetMostPopularProduct());
    }
}
